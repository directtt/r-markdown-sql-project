USE [dbad_flights];
GO

DROP INDEX IF EXISTS [idx_dow_adn] ON [dbo].[Flight_delays]
GO
DROP INDEX IF EXISTS [idx_cov_o_ai] ON [dbo].[Flight_delays]
GO
DROP INDEX IF EXISTS [idx_arr_delay_new] ON [dbo].[Flight_delays]
GO
DROP INDEX IF EXISTS [idx_ai_adn] ON [dbo].[Flight_delays]
GO
DROP INDEX IF EXISTS [idx_adn_ddn] ON [dbo].[Flight_delays]
GO

DROP TABLE IF EXISTS [dbo].[Airlines];
GO
DROP TABLE IF EXISTS [dbo].[Airports];
GO
DROP TABLE IF EXISTS [dbo].[Flight_delays];
GO
DROP TABLE IF EXISTS [dbo].[Weather];
GO
DROP TABLE IF EXISTS [dbo].[Weekdays];
GO

CREATE TABLE [dbo].[Airlines]
(
    [airline_id]   [INT] NOT NULL,
    [airline_name] [NVARCHAR](MAX) NOT NULL,
    CONSTRAINT [pk_airline] PRIMARY KEY CLUSTERED ([airline_id] ASC)
);
GO

CREATE TABLE [dbo].[Airports]
(
    [airport_id]   [INT] NOT NULL,
    [airport_name] [NVARCHAR](MAX) NOT NULL,
    CONSTRAINT [pk_airport] PRIMARY KEY CLUSTERED ([airport_id] ASC)
);
GO

CREATE TABLE [dbo].[Flight_delays]
(
    [year]                  [INT] NOT NULL,
    [quarter]               [INT] NOT NULL,
    [month]                 [INT] NOT NULL,
    [day_of_month]          [INT] NOT NULL,
    [day_of_week]           [INT] NOT NULL,
    [fl_date]               [DATE] NOT NULL,
    [unique_carrier]        [NVARCHAR](MAX) NOT NULL,
    [airline_id]            [INT] NOT NULL,
    [carrier]               [NVARCHAR](MAX) NOT NULL,
    [tail_num]              [NVARCHAR](MAX) NULL,
    [fl_num]                [INT] NOT NULL,
    [origin_airport_id]     [INT] NULL,
    [origin_airport_seq_id] [INT] NULL,
    [origin_city_market_id] [INT] NULL,
    [origin]                [NVARCHAR](3) NOT NULL,
    [origin_city_name]      [NVARCHAR](MAX) NOT NULL,
    [origin_state_abr]      [NVARCHAR](MAX) NOT NULL,
    [origin_state_fips]     [INT] NULL,
    [origin_state_nm]       [NVARCHAR](MAX) NOT NULL,
    [origin_wac]            [INT] NULL,
    [dest_airport_id]       [INT] NULL,
    [dest_airport_seq_id]   [INT] NULL,
    [dest_city_market_id]   [INT] NULL,
    [dest]                  [NVARCHAR](MAX) NOT NULL,
    [dest_city_name]        [NVARCHAR](MAX) NOT NULL,
    [dest_state_abr]        [NVARCHAR](MAX) NOT NULL,
    [dest_state_fips]       [INT] NULL,
    [dest_state_nm]         [NVARCHAR](MAX) NOT NULL,
    [dest_wac]              [INT] NULL,
    [crs_dep_time]          [INT] NOT NULL,
    [dep_time]              [FLOAT] NULL,
    [dep_delay]             [FLOAT] NULL,
    [dep_delay_new]         [FLOAT] NULL,
    [dep_del15]             [FLOAT] NULL,
    [dep_delay_group]       [FLOAT] NULL,
    [dep_time_blk]          [NVARCHAR](MAX) NOT NULL,
    [taxi_out]              [FLOAT] NULL,
    [wheels_off]            [FLOAT] NULL,
    [wheels_on]             [FLOAT] NULL,
    [taxi_in]               [FLOAT] NULL,
    [crs_arr_time]          [INT] NULL,
    [arr_time]              [FLOAT] NULL,
    [arr_delay]             [FLOAT] NULL,
    [arr_delay_new]         [FLOAT] NULL,
    [arr_del15]             [FLOAT] NULL,
    [arr_delay_group]       [FLOAT] NULL,
    [arr_time_blk]          [NVARCHAR](MAX) NOT NULL,
    [cancelled]             [FLOAT] NULL,
    [cancellation_code]     [NVARCHAR](MAX) NULL,
    [diverted]              [FLOAT] NULL,
    [carrier_delay]         [FLOAT] NULL,
    [weather_delay]         [FLOAT] NULL,
    [nas_delay]             [FLOAT] NULL,
    [security_delay]        [FLOAT] NULL,
    [late_aircraft_delay]   [FLOAT] NULL,
    [unnamed: 55]           [FLOAT] NULL
);
GO

CREATE TABLE [dbo].[Weather]
(
    [station]                           [NVARCHAR](10) NOT NULL,
    [station_name]                      [NVARCHAR](MAX) NOT NULL,
    [elevation]                         [FLOAT] NULL,
    [latitude]                          [FLOAT] NULL,
    [longitude]                         [FLOAT] NULL,
    [date]                              [NVARCHAR](16) NOT NULL,
    [reporttpye]                        [NVARCHAR](MAX) NOT NULL,
    [hourlyskyconditions]               [NVARCHAR](MAX) NULL,
    [hourlyvisibility]                  [FLOAT] NULL,
    [hourlyprsentweathertype]           [FLOAT] NULL,
    [hourlydrybulbtempf]                [FLOAT] NULL,
    [hourlydrybulbtempc]                [FLOAT] NULL,
    [hourlywetbulbtempf]                [FLOAT] NULL,
    [hourlywetbulbtempc]                [FLOAT] NULL,
    [hourlydewpointtempf]               [FLOAT] NULL,
    [hourlydewpointtempc]               [FLOAT] NULL,
    [hourlyrelativehumidity]            [FLOAT] NULL,
    [hourlywindspeed]                   [FLOAT] NULL,
    [hourlywinddirection]               [NVARCHAR](MAX) NULL,
    [hourlywindgustspeed]               [FLOAT] NULL,
    [hourlystationpressure]             [FLOAT] NULL,
    [hourlypressuretendency]            [FLOAT] NULL,
    [hourlypressurechange]              [FLOAT] NULL,
    [hourlysealevelpressure]            [FLOAT] NULL,
    [hourlyprecip]                      [FLOAT] NULL,
    [hourlyaltimetersetting]            [FLOAT] NULL,
    [dailymaximumdrybulbtemp]           [FLOAT] NULL,
    [dailyminimumdrybulbtemp]           [FLOAT] NULL,
    [dailyaveragedrybulbtemp]           [FLOAT] NULL,
    [dailydeptfromnormalaveragetemp]    [FLOAT] NULL,
    [dailyaveragerelativehumidity]      [FLOAT] NULL,
    [dailyaveragedewpointtemp]          [FLOAT] NULL,
    [dailyaveragewetbulbtemp]           [FLOAT] NULL,
    [dailyheatingdegreedays]            [FLOAT] NULL,
    [dailycoolingdegreedays]            [FLOAT] NULL,
    [dailysunrise]                      [INT] NULL,
    [dailysunset]                       [INT] NULL,
    [dailyweather]                      [FLOAT] NULL,
    [dailyprecip]                       [FLOAT] NULL,
    [dailysnowfall]                     [FLOAT] NULL,
    [dailysnowdepth]                    [FLOAT] NULL,
    [dailyaveragestationpressure]       [FLOAT] NULL,
    [dailyaveragesealevelpressure]      [FLOAT] NULL,
    [dailyaveragewindspeed]             [FLOAT] NULL,
    [dailypeakwindspeed]                [FLOAT] NULL,
    [peakwinddirection]                 [FLOAT] NULL,
    [dailysustainedwindspeed]           [FLOAT] NULL,
    [dailysustainedwinddirection]       [FLOAT] NULL,
    [monthlymaximumtemp]                [FLOAT] NULL,
    [monthlyminimumtemp]                [FLOAT] NULL,
    [monthlymeantemp]                   [FLOAT] NULL,
    [monthlyaveragerh]                  [FLOAT] NULL,
    [monthlydewpointtemp]               [FLOAT] NULL,
    [monthlywetbulbtemp]                [FLOAT] NULL,
    [monthlyavgheatingdegreedays]       [FLOAT] NULL,
    [monthlyavgcoolingdegreedays]       [FLOAT] NULL,
    [monthlystationpressure]            [FLOAT] NULL,
    [monthlysealevelpressure]           [FLOAT] NULL,
    [monthlyaveragewindspeed]           [FLOAT] NULL,
    [monthlytotalsnowfall]              [FLOAT] NULL,
    [monthlydeptfromnormalmaximumtemp]  [FLOAT] NULL,
    [monthlydeptfromnormalminimumtemp]  [FLOAT] NULL,
    [monthlydeptfromnormalaveragetemp]  [FLOAT] NULL,
    [monthlydeptfromnormalprecip]       [FLOAT] NULL,
    [monthlytotalliquidprecip]          [FLOAT] NULL,
    [monthlygreatestprecip]             [FLOAT] NULL,
    [monthlygreatestprecipdate]         [FLOAT] NULL,
    [monthlygreatestsnowfall]           [FLOAT] NULL,
    [monthlygreatestsnowfalldate]       [FLOAT] NULL,
    [monthlygreatestsnowdepth]          [FLOAT] NULL,
    [monthlygreatestsnowdepthdate]      [FLOAT] NULL,
    [monthlydayswithgt90temp]           [FLOAT] NULL,
    [monthlydayswithlt32temp]           [FLOAT] NULL,
    [monthlydayswithgt32temp]           [FLOAT] NULL,
    [monthlydayswithlt0temp]            [FLOAT] NULL,
    [monthlydayswithgt001precip]        [FLOAT] NULL,
    [monthlydayswithgt010precip]        [FLOAT] NULL,
    [monthlydayswithgt1snow]            [FLOAT] NULL,
    [monthlymaxsealevelpressurevalue]   [FLOAT] NULL,
    [monthlymaxsealevelpressuredate]    [INT] NULL,
    [monthlymaxsealevelpressuretime]    [INT] NULL,
    [monthlyminsealevelpressurevalue]   [FLOAT] NULL,
    [monthlyminsealevelpressuredate]    [INT] NULL,
    [monthlyminsealevelpressuretime]    [INT] NULL,
    [monthlytotalheatingdegreedays]     [NVARCHAR](MAX) NULL,
    [monthlytotalcoolingdegreedays]     [NVARCHAR](MAX) NULL,
    [monthlydeptfromnormalheatingdd]    [NVARCHAR](MAX) NULL,
    [monthlydeptfromnormalcoolingdd]    [NVARCHAR](MAX) NULL,
    [monthlytotalseasontodateheatingdd] [FLOAT] NULL,
    [monthlytotalseasontodatecoolingdd] [FLOAT] NULL,
    [day_of_month]                      [INT] NULL,
    CONSTRAINT [pk_station_date] PRIMARY KEY CLUSTERED ([station] ASC, [date] ASC)
);
GO

CREATE TABLE [dbo].[Weekdays]
(
    [weekday_id]    [INT] NOT NULL,
    [weekday_name]  [NVARCHAR](MAX) NOT NULL,
    CONSTRAINT [pk_weekday] PRIMARY KEY CLUSTERED ([weekday_id] ASC)
);
GO
