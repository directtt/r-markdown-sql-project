USE [dbad_flights];
GO

CREATE NONCLUSTERED INDEX [idx_adn_ddn] ON [dbo].[Flight_delays]
(
    [arr_delay_new] ASC,
    [dep_delay_new] ASC
);
GO

CREATE NONCLUSTERED INDEX [idx_ai_adn] ON [dbo].[Flight_delays]
(
    [airline_id]    ASC,
    [arr_delay_new] ASC
);
GO

CREATE NONCLUSTERED INDEX [idx_arr_delay_new] ON [dbo].[Flight_delays]
(
    [arr_delay_new] ASC
);
GO

CREATE NONCLUSTERED INDEX [idx_cov_o_ai] ON [dbo].[Flight_delays]
(
    [origin] ASC
)
INCLUDE ([airline_id]);
GO

CREATE NONCLUSTERED INDEX [idx_dow_adn] ON [dbo].[Flight_delays]
(
    [day_of_week]   ASC,
    [arr_delay_new] ASC
);
GO
