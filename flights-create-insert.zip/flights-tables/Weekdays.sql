USE [dbad_flights];
GO

DELETE FROM [dbo].[Weekdays];
GO

INSERT [dbo].[Weekdays] VALUES 
(1, N'Monday'),
(2, N'Tuesday'),
(3, N'Wednesday'),
(4, N'Thursday'),
(5, N'Friday'),
(6, N'Saturday'),
(7, N'Sunday'),
(9, N'Unknown');
